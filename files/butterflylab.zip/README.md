Welcome to ButterflyLab!

This week's lab is basically doing a modified version of the emacs tutorial.
This tutorial is an interactive hands-on which will familiarize you with many
things.

To get started, open the file `emacs-tutorial` on emacs.

You should carefully follow the instructions in that file. There are 4
checkpoints. Each checkpoint will ask you to type a sequence of commands that
will dump all the keys that you have type while doing the
tutorial into some files: `checkpoint1.keys`, `checkpoint2.keys`, `checkpoint3.keys` and
`checkpoint4.keys`.

To submit your work to Autolab, use `make`, and scp the handin.zip file to your
laptop to upload it to Autolab:

    # From Andrew:
    $ make

    # From your laptop
    # Mac/Linux
    $ scp ANDREWID@unix.andrew.cmu.edu:~/path/to/your/handin.zip .
    # Windows:
    $ scp ANDREWID@unix.andrew.cmu.edu:~/path/to/handin.zip /mnt/c/Users/USERNAME/Downloads/
