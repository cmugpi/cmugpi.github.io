if [ "$0" != "bash" ]; then
  echo "You need to complete this puzzle using Bash."
  return
fi

confirm_kernelfleet_message () {
 ./confirm $1 5cee7230364b924277ab9a4e2230966211f623dd640c0aee9b7dd4e0fc90966c \
       && cd yklim_yaw/atled_tnardauq/societies/sevitcelloc/grob/holding_area \
       && export PS1_OLD=$PS1 \
       && export PS1="$ "
}

kernelfleet_beacon () {
  ./beacon 12a998e908256469f21d838312747a595c495b373597f90774de0f3016f16c66 \
    $@ \
    && export PS1=$PS1_OLD
}

